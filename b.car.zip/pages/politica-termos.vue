<template>
    <main class="policy-privacy">
        <ElementsContainer class="container">
            <article class="pb-20 xl:pb-28 pt-big">
                <h1 class="mb-8 md:mb-16 uppercase">Política e termos <br> de privacidade</h1>

                <p>
                    The Privacy Act 2020 gives you the right to request access to your personal information held by Finsol. If you would like to access, correct or change the collected information at any time, please get in touch with our Privacy Officer by email at finsol@finsol.co.nz. Visit www.privacy.org.nz for more details on the Act.

                    <br><br>

                    <strong>Changes to this policy <br></strong>
                    We may change this policy by uploading a revised policy. The change will apply from the date that we upload the revised policy (noted at the bottom).

                    <br><br>

                    <strong>What is personal information? <br></strong>
                    Personal information is information about an identifiable individual. It includes (but is not limited to) name, address, contact details, date of birth, occupations, payment details, employment history and/or details, education and qualifications, financial information, testimonials and feedback, evidence of source of funds or source of wealth (in some cases) and other information.

                    <br><br>

                    When you deal with us, you consent to us using, disclosing and handling your personal information in accordance with this privacy statement. Please note we never pass on your personal information to any third party without your approval.

                    <br><br>

                    We collect your personal information so we can: 
                    <br>
                    to verify your identity
                    <br>
                    to provide services and products to you
                    to market our services and products to you, including contacting you electronically (e.g. by call, text or email for this purpose)
                    to improve the services and products that we provide to you
                    to respond to communications from you, including a complaint
                    to protect and/or enforce our legal rights and interests, including defending any claim
                    <br>
                    for any other purpose authorised by you or the Act.
                    <br>
                    If you do not provide the information required, it may affect our ability to provide you with our services. You are responsible for supplying us with all relevant information promptly, including all information that may be relevant to an insurer's assessment of a claim or a risk for which you have asked us to arrange insurance cover.
                </p>
            </article>
        </ElementsContainer>
    </main>
</template>

<style lang="scss" scoped>
.container {
    max-width: 790px;

    h1 {
        font: 700 48px/52px $gotham;

        @media screen and (max-width: $mobile) {
            font: 700 24px/32px $gotham;
        }
    }

    p {
        font: 400 18px/26px $inter;

        @media screen and (max-width: $mobile) {
            font: 400 16px/24px $inter;
        }
    }
}
</style>