<template>
  <div class="__app">
    <LayoutNavbar full shadow />
    <slot />
  </div>
</template>
