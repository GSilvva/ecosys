<template>
  <div class="__app">
    <LayoutNavbar />
    <slot />
  </div>
</template>
