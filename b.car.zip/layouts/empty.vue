<template>
  <div class="__app">
    <slot />
  </div>
</template>
