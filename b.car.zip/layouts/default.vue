<template>
  <div class="__app">
    <LayoutNavbar />
    <slot />
    <LayoutFooter />
  </div>
</template>